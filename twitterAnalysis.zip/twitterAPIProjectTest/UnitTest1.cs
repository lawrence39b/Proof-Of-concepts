//using Microsoft.VisualStudio.TestTools.UnitTesting;
//using twitterAnalysis;
//using twitterAnalysis.BAL;
//using twitterAnalysis.requests;

//namespace twitterAPIProjectTest
//{
//    [TestClass]
//    public class UnitTest1
//    {
//        [Ignore]
//        [TestMethod]
//        public void AverageTweets()
//        {
//            averageTweets avgTs = new averageTweets();
//            readTwitterSampleData testObject = new readTwitterSampleData(avgTs);

//            int result = testObject.getResult();

//            Assert.AreNotEqual(0, result);
//        }

//        [Ignore]
//        [TestMethod]
//        public void numberOfTweets()
//        {
//            numberofTweets numTweets = new numberofTweets();
//            readTwitterSampleData testObject = new readTwitterSampleData(numTweets);

//            int result = testObject.getResult();

//            Assert.AreNotEqual(0, result);
//        }

//        [Ignore]
//        [TestMethod]
//        public void PercentTweetsWithEmojis()
//        {
//            percentTweetsWithEmojis withEmojis = new percentTweetsWithEmojis();
//            readTwitterSampleData testObject = new readTwitterSampleData(withEmojis);

//            int result = testObject.getResult();

//            Assert.AreNotEqual(0, result);
//        }

//        [Ignore]
//        [TestMethod]
//        public void PercentTweetsWithURLs()
//        {
//            percentTweetsWithURL withURLS = new percentTweetsWithURL();
//            readTwitterSampleData testObject = new readTwitterSampleData(withURLS);

//            int result = testObject.getResult();

//            Assert.AreNotEqual(0, result);
//        }

//        [Ignore]
//        [TestMethod]
//        public void PercentTweetsWithPhotoURLs()
//        {
//            percentTweetsWithPhotoURL withPhotoURLS = new percentTweetsWithPhotoURL();
//            readTwitterSampleData testObject = new readTwitterSampleData(withPhotoURLS);

//            int result = testObject.getResult();

//            Assert.AreNotEqual(0, result);
//        }

//        [Ignore]
//        [TestMethod]
//        public void TopDomainURLs()
//        {
//            topDomainURLs topDURLs = new topDomainURLs();
//            //readTwitterSampleData testObject = new readTwitterSampleData(topDURLs);

//            //int result = testObject.getResult();

//            //Assert.AreNotEqual(0, result);
//        }
//    }
//}
