﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using twitterAnalysis.interfaces;

namespace twitterAnalysis.requests
{
    public class topDomainURLs : ItwitterSampleDataValue
    {
        private string topDomain = "topDomain.now";
        public string getValue()
        {
            return topDomain;
        }

        public string setTopDomain( string topdomain)
        {
            this.topDomain = topdomain;
            return this.topDomain;
        }
    }
}
