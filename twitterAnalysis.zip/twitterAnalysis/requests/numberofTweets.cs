﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using twitterAnalysis.BAL;
using twitterAnalysis.interfaces;

namespace twitterAnalysis.requests
{
    public class numberofTweets : ITwitterSampleData
    {
        private int NumberOfTweets = 0;

        public int getResult()
        {
            return processStreamData.numberofTweets;
            //return NumberOfTweets;
        }

        public void setValue()
        {
            this.NumberOfTweets = processStreamData.numberofTweets;
        }
    }
}
