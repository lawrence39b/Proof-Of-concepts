﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using twitterAnalysis.interfaces;

namespace twitterAnalysis.requests
{
    public class percentTweetsWithPhotoURL : ITwitterSampleData
    {
        public int getResult()
        {
            return 5;
            //throw new NotImplementedException();
        }
    }
}
