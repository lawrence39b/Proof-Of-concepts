﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using twitterAnalysis.interfaces;

namespace twitterAnalysis.requests
{
    public class topEmojis : ItwitterSampleDataValue
    {
        public string getValue()
        {
            return "smile";
        }
    }
}
