﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace twitterAnalysis.interfaces
{
    public interface ITwitterSampleData
    {
        public Int32 getResult();
    }
}
