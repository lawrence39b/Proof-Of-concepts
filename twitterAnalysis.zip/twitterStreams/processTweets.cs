﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace twitterData
{
    // class processTweets
    //public class processTweets
    public sealed class processTweets : processTweetsBase
    {
        private int Number_Of_Hashtags_Displayed = 3;
        private int Number_Of_Domains_Displayed = 3;
        private int Number_Of_Emojis_Displayed = 1;
        processTweets()
        {
            #region CONFIGURATION
            Dictionary<string, string> appsettings = new Dictionary<string, string>();
            applicationConfig appConfig = new applicationConfig(System.IO.Path.GetDirectoryName(Environment.GetCommandLineArgs()[0]));
            appsettings = appConfig.getAppSettings();

            Number_Of_Hashtags_Displayed = Convert.ToInt32(appsettings["NUMBER_HASH_TAGS_TO_DISPLAY"]);
            Number_Of_Domains_Displayed = Convert.ToInt32(appsettings["NUMBER_DOMAINS_TO_DISPLAY"]);
            Number_Of_Emojis_Displayed = Convert.ToInt32(appsettings["NUMBER_EMOJIS_TO_DISPLAY"]);


            #endregion
            //counttimer = new CountTimer();
        }
        private static readonly object mylock = new object();
        private static processTweets instance = null;
        //public double percentofTweetsWitlRLs;
        //public int numberofTweetsWithEmojis;


        //Date Time 
        DateTime startDateTime = DateTime.Now;
       

        public static processTweets Instance
        {
            get
            {
                lock (mylock)
                {
                    if (instance == null)
                    {
                        instance = new processTweets();
                    }
                    return instance;
                }
            }
        }

        //public static string[] analizeData()
        public string[] analizeData()
        {
            #region TOP+DOMAINS
            //Get Top Domains
            List<KeyValuePair<string, int>> domainList = domainDictionary.ToList();
            domainList.Sort(Compare);
            int range = (Number_Of_Domains_Displayed > 0) ? Number_Of_Domains_Displayed : 1;

            string dms = string.Empty;
            for(int i=0; i < range; i++)
            {
                if(i <= domainList.Count-1)
                    dms += (string.IsNullOrEmpty(dms)) ? domainList[i].Key : ", " + domainList[i].Key;
            }
            string topDomain = dms;
            #endregion

            #region TOP_HASHTAGS
            //Get Top HashTags
            List<KeyValuePair<string, int>> hashTagList = hasTagDictionary.ToList();
            hashTagList.Sort(Compare);
            
            int range2 = (Number_Of_Hashtags_Displayed > 0) ? Number_Of_Hashtags_Displayed : 1;
            string tgs = string.Empty;
            for (int i = 0; i < range2; i++)
            {
                if(i<= hashTagList.Count-1)
                    tgs += (string.IsNullOrEmpty(tgs)) ? hashTagList[i].Key : ", " + hashTagList[i].Key;
            }
            string topHashTag = tgs;
            #endregion

            #region TOP_EMOJIS
                //Get Top HashTags
            List<KeyValuePair<string, int>> emojiList = emojiDictionary.ToList();
            emojiList.Sort(Compare);

            int range3 = (Number_Of_Emojis_Displayed > 0) ? Number_Of_Emojis_Displayed : 1;
            string emj = string.Empty;
            for (int i = 0; i < range3; i++)
            {
                if (i <= emojiList.Count - 1)
                    emj += (string.IsNullOrEmpty(emj)) ? emojiList[i].Key : ", " + emojiList[i].Key;
            }
            string emoji = emj;
            #endregion

            string[] st1 = new string[] {
                 "Number of Tweets recieved: => " + numberofTweets.ToString(),
                 "\nFrequency of Tweets (per unit of time):",
                 "\tHour: => " + tweetsPerHour + "; Minute: => " + tweetsPerMinute.ToString() +"; Second: => " + tweetsPerSecond.ToString(),
                 //"\tTweets per Second: " + tweetsPerSecond.ToString() + "\n \tTweets per Minute: " + tweetsPerMinute.ToString() + "\n \tTweets per Hour: " + tweetsPerHour,
                 "\nPercent of Tweets with URL: => " + (percentofTweetsWithURLs * 100.00).ToString("N2") + "%",
                 "Percent of Tweets with Photo URL: => " + (percentofTweetsWithPhotoURL * 100.00).ToString("N2") + "%",
                 "Percent of Tweets with Emojis: => " + (percentofTweetsWithEmojis * 100.00).ToString("N2") + "%",
                 //"\nNumber of Tweets with URLs: => " + numberofTweetsWithURL.ToString(),
                 "Top (" + Number_Of_Hashtags_Displayed + ") Hashtags: => [ " + topHashTag + " ]",
                 "Top (" + Number_Of_Domains_Displayed + ") Domains: => [ " + topDomain+ " ]",
                 //"Number of Tweets with Emojis: => " + numberofTweetsWithEmojis.ToString(),
                 "Top Emoji(s): => " + "[ " + emoji + " ]",
                 "=============================================================================="
            };

            return st1;
        }

        static int Compare(KeyValuePair<string, int> a, KeyValuePair<string, int> b)
        {
            return b.Value.CompareTo(a.Value);
        }

        public void RESET()
        {
            numberofTweets = 0;
            numberofTweetsWithURL = 0;
            percentofTweetsWithEmojis = 0.0;
            percentofTweetsWithPhotoURL = 0;
            percentofTweetsWithURLs = 0;
            percentofTweetsWithEmojis = 0.0;
            topEmoji = "";
            tweetsPerSecond = 0;
            tweetsPerMinute = 0;
            tweetsPerHour = 0;

            domainDictionary.Clear();
            hasTagDictionary.Clear();
        }
        public static void compute(DateTime startDateTime)
        {
            DateTime curent = DateTime.Now;
            TimeSpan timespan = curent.Subtract(startDateTime);

            try
            {
                //Calculate Counts
                instance.tweetsPerSecond = instance.numberofTweets / timespan.Seconds;
                instance.tweetsPerMinute = (timespan.Minutes <= 0) ? instance.numberofTweets : (instance.numberofTweets / timespan.Minutes);

                //Calculate Counts
                instance.tweetsPerHour = (timespan.Hours <= 0) ? instance.numberofTweets : instance.numberofTweets / timespan.Hours;

                instance.percentofTweetsWithPhotoURL = (instance.numberofTweets > 0) ? ((double)instance.numberofTweetsWitlPhotoURL / (double)instance.numberofTweets) : 1.0;

                instance.percentofTweetsWithURLs = (instance.numberofTweets > 0) ? ((double)instance.numberofTweetsWithURL / (double)instance.numberofTweets) : 1.0;

                instance.percentofTweetsWithEmojis = (instance.numberofTweets > 0) ? ((double)instance.numberofTweetsWithEmojis / (double)instance.numberofTweets) : 1.0;

            }
            catch
            {
                //Catch exception and continue;
                // possible divide by zero will not affect count or processing.
            }
            //Display Data
            displayData();
        }

        private static void displayData()
        {
            foreach (string item in instance.analizeData())
            {
                Console.WriteLine(item);
            }
            Console.WriteLine(Environment.NewLine); ;
        }
    }


}
