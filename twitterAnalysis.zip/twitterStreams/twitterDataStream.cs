﻿using System;
//using twitterStreams;
using Tweetinvi;
using Tweetinvi.Models;
using Tweetinvi.Auth;
using System.Threading;
using System.Threading.Tasks;
using twitterData;
using System.Text.RegularExpressions;
using System.Collections.Generic;

namespace twitterStreams
{
    public class twitterDataStream
    {

        static DateTime startDateTime = DateTime.Now;

        static processTweets tweetProcessor = processTweets.Instance;
        static Dictionary<string, string> appsettings = new Dictionary<string, string>();

        static async Task Main(string[] args)
        {
            await streamTwitterData();
        }

        private static async Task streamTwitterData()
        //private static async Task streamTwitterData()
        {
    #region CONFIGURATION
            applicationConfig appConfig = new applicationConfig(System.IO.Path.GetDirectoryName(Environment.GetCommandLineArgs()[0]));
            appsettings = appConfig.getAppSettings();

            var appClient = new TwitterClient(appsettings["API_KEY"], appsettings[("API_SECRET_KEY")]);
            var userClient = new TwitterClient(appsettings["API_KEY"], appsettings[("API_SECRET_KEY")], appsettings["ACCESS_TOKEN"], appsettings[("ACCESS_TOKEN_SECRET")]);
    #endregion

            //Frequency Timer
            Timer Timer;
            var emojiPatternMatch = @"(\u00a9|\u00ae|[\u2000-\u3300] |\ud83c[\ud000-\udfff]|\ud83d[\ud000-\udfff]|\ud83e[\ud000-\udfff])";
            emojiPatternMatch = @"(\u00a9|\u00ae|[\u2000-\u3300]|\ud83c[\ud000-\udfff]|\ud83d[\ud000-\udfff]|\ud83e[\ud000-\udfff])";

            //Get User
            var user = await userClient.Users.GetAuthenticatedUserAsync();
            //Console.WriteLine(user);

            // Tweet Stream
            var sampleStream = userClient.Streams.CreateSampleStream();
            Console.WriteLine("Opening Twitter Stream...");

            //Start Timer
            int timerMillliSeconds = 500;
            Int32.TryParse(appsettings["TIMER_FREQUENCY_MILLISECONDS"], out timerMillliSeconds);

            Timer = new Timer(tallyFrequencies, null, 1000, timerMillliSeconds);

            try
            {
                // Tweets steam Event Handler 
                sampleStream.TweetReceived += (sender, eventArgs) =>
                {
                    //Increment tweet Count;
                    tweetProcessor.numberofTweets++;
    #region PHOTOS_AND_EMOJIS
                    if (eventArgs.Tweet.Entities.Medias.Count > 0)
                    {
        #region PHOTOS
                        //Tweets With Photos; increment count
                        if (eventArgs.Tweet.Entities.Medias.Find(photo => (photo.MediaType == "photo")) != null)
                            tweetProcessor.numberofTweetsWitlPhotoURL++;
        #endregion

        #region EMOJIS

                        MatchCollection emojiMatch = Regex.Matches(eventArgs.Tweet.Text, emojiPatternMatch);
                        if (emojiMatch.Count > 0)
                        {
                            foreach (var item in emojiMatch)
                            {
                                var emoji = item.ToString();
                                if (tweetProcessor.emojiDictionary.ContainsKey(emoji))
                                {
                                    tweetProcessor.emojiDictionary[emoji] += 1;
                                }
                                else
                                {
                                    tweetProcessor.emojiDictionary.Add(emoji, 1);
                                }
                            }
                            tweetProcessor.numberofTweetsWithEmojis++;
                        }

        #endregion
                    }
    #endregion
    #region DOMAINS
                    Uri s2;
                    string domain = null;
                    //Locate and count domains in URL collection
                    var domainsFound = Regex.Matches(eventArgs.Tweet.Source, @"http(s)?://([\w-]+.)+[\w-]+(/[\w- ./?%&=])?");
                    if (domainsFound.Count > 0)
                    {
                        s2 = new Uri(domainsFound[0].Value);
                        domain = s2.Host;
                    }

                    if (!string.IsNullOrEmpty(domain))
                    {
                        if (tweetProcessor.domainDictionary.ContainsKey(domain))
                        {
                            tweetProcessor.domainDictionary[domain] += 1;
                        }
                        else
                        {
                            tweetProcessor.domainDictionary.Add(domain, 1);
                        }
                    }
    #endregion

    #region HASHTAGS
                    //Tweets with Hash Tags
                    if (eventArgs.Tweet.Entities.Hashtags.Count > 0)
                    {
                        eventArgs.Tweet.Entities.Hashtags.ForEach(tag =>
                        {

                            if (tweetProcessor.hasTagDictionary.ContainsKey(tag.Text))
                            {
                                tweetProcessor.hasTagDictionary[tag.Text]++;
                            }
                            else
                            {
                                tweetProcessor.hasTagDictionary.Add(tag.Text, 1);
                            }
                        });
                    }
    #endregion

    #region CONTAINURLS
                    //Tweets with URLs
                    if (eventArgs.Tweet.Entities.Urls.Count > 0)
                        tweetProcessor.numberofTweetsWithURL++;
    #endregion

                };

                await sampleStream.StartAsync();
            }
            catch (Exception ex)
            {
                Console.WriteLine("exception [{0}]reading Tweets;", ex.Message);
                //sampleStream.Resume();
                sampleStream.Stop();
                await sampleStream.StartAsync();
            }

            // Dispose of frequency Timer
            if (Timer != null)
                Timer.Dispose();
        }

        private static void tallyFrequencies(object state)
        {
            processTweets.compute(startDateTime);
        }
    }
}

