﻿using System;
using System.Collections.Generic;
using System.Text;

namespace twitterData.interfaces
{
    class IdictionaryList
    {
    }
}
