﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace twitterData.interfaces
{
    public interface ITwitterSampleData
    {
        public Int32 getResult();
    }
}
