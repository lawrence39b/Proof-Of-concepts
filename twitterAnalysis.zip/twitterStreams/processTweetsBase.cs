﻿using System.Collections.Generic;

namespace twitterData
{
    public class processTweetsBase
    {
        //public static int percentofTweetsWithURL;
        public static string topEmoji;

        // Data collector variables

        public int numberofTweets;
        public int numberofTweetsWithURL;
        public int numberofTweetsWitlPhotoURL;
        public int numberofTweetsWithEmojis;
        public double percentofTweetsWithEmojis;
        public double percentofTweetsWithPhotoURL;
        public double percentofTweetsWithURLs;

        public int tweetsPerSecond;
        public int tweetsPerMinute;
        public int tweetsPerHour;


        public Dictionary<string, int> domainDictionary = new Dictionary<string, int>();
        public Dictionary<string, int> hasTagDictionary = new Dictionary<string, int>();
        public Dictionary<string, int> emojiDictionary = new Dictionary<string, int>();

        
    }
}