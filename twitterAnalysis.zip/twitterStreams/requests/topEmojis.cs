﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using twitterData.interfaces;

namespace twitterData.requests
{
    public class topEmojis : ItwitterSampleDataValue
    {
        private string topEmoji = "topEmoji";
        Dictionary<string, int> emojiDict;

        public string getValue()
        {

            emojiDict = processTweets.Instance.emojiDictionary;

            return topEmoji;
        }

        public string setTopDomain(string topdomain)
        {
            //Get Top Emoji
            List<KeyValuePair<string, int>> emojiList = emojiDict.ToList();
            emojiList.Sort(Compare);

            int range2 = (3 > 0) ? 3 : 1;
            string tgs = string.Empty;
            for (int i = 0; i < range2; i++)
            {
                if (i <= emojiList.Count - 1)
                    tgs += (string.IsNullOrEmpty(tgs)) ? emojiList[i].Key : ", " + emojiList[i].Key;
            }
            string topHashTag = tgs;
            ;
            return this.topEmoji;
        }

        static int Compare(KeyValuePair<string, int> a, KeyValuePair<string, int> b)
        {
            return b.Value.CompareTo(a.Value);
        }
    }
}
