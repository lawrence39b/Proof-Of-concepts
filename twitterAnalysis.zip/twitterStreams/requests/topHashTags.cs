﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using twitterData.interfaces;

namespace twitterData.requests
{
    public class topHashTags : ItwitterSampleDataValue
    {
        private string tophashtags = "GameStop";
        Dictionary<string, int> hashTagDict;

        public string getValue()
        {

            hashTagDict = processTweets.Instance.emojiDictionary;

            return tophashtags;
        }

        public string setTopDomain(string topdomain)
        {

            processTweets.Instance.emojiDictionary.Add(topdomain, 99999);
            //Get Top Emoji
            List<KeyValuePair<string, int>> hashTagList = hashTagDict.ToList();
            hashTagList.Sort(Compare);

            int range2 = (3 > 0) ? 3 : 1;
            string tgs = string.Empty;
            for (int i = 0; i < range2; i++)
            {
                if (i <= hashTagList.Count - 1)
                    tgs += (string.IsNullOrEmpty(tgs)) ? hashTagList[i].Key : ", " + hashTagList[i].Key;
            }
            string topHashTag = tgs;
            
            return this.tophashtags;
        }

        static int Compare(KeyValuePair<string, int> a, KeyValuePair<string, int> b)
        {
            return b.Value.CompareTo(a.Value);
        }
    }
}
