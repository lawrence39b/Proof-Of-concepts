﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using twitterData.interfaces;

namespace twitterData.requests
{
    public class percentTweetsWithEmojis : ITwitterSampleData
    {
        public int getResult()
        {
            //Return the rate as a whole number  (percent * 100)

            return Convert.ToInt32((processTweets.Instance.percentofTweetsWithEmojis * 100));
        }
    }
}
