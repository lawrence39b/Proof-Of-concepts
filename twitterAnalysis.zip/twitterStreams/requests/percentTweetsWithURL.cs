﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using twitterData.interfaces;

namespace twitterData.requests
{
    public class percentTweetsWithURL : ITwitterSampleData
    {
        public int getResult()
        {
            return Convert.ToInt32(((processTweets.Instance.numberofTweetsWithURL / processTweets.Instance.numberofTweets) * 100)); 
        }
    }
}
