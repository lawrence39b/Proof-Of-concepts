﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using twitterData.interfaces;

namespace twitterData.requests
{
    public class topDomainURLs : ItwitterSampleDataValue
    {
        private string topDomain = "topDomain.now";
        Dictionary<string, int> domainDict;

        public string getValue()
        {

            domainDict = processTweets.Instance.domainDictionary;

            return topDomain;
        }

        public string setTopDomain( string topdomain)
        {
            //Get Top HashTags
            List<KeyValuePair<string, int>> hashTagList = domainDict.ToList();
            hashTagList.Sort(Compare);

            int range2 = (3 > 0) ? 3 : 1;
            string tgs = string.Empty;
            for (int i = 0; i < range2; i++)
            {
                if (i <= hashTagList.Count - 1)
                    tgs += (string.IsNullOrEmpty(tgs)) ? hashTagList[i].Key : ", " + hashTagList[i].Key;
            }
            string topHashTag = tgs; 
            ;
            return this.topDomain;
        }

        static int Compare(KeyValuePair<string, int> a, KeyValuePair<string, int> b)
        {
            return b.Value.CompareTo(a.Value);
        }
    }
}
