﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using twitterData.interfaces;

namespace twitterData.requests
{
    public class twitterData : ITwitterSampleData
    {
        public int getResult()
        {
            //returned as applicationConfig whole Numbeer
             return Convert.ToInt32((processTweets.Instance.percentofTweetsWithPhotoURL * 100));
        }
    }
}
