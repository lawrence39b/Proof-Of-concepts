﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using twitterData.interfaces;

namespace twitterData.requests
{
    public class numberofTweets : ITwitterSampleData
    {
        private int NumberOfTweets = 0;

        public int getResult()
        {
            return processTweets.Instance.numberofTweets;
        }

        public void setValue()  
        {
            this.NumberOfTweets = processTweets.Instance.numberofTweets;
        }
    }
}
