﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using twitterData.interfaces;

namespace twitterData.requests
{
    public class averageTweets : ITwitterSampleData
    {
        public int getResult()
        {
            //this method is not used.
           return processTweets.Instance.numberofTweets;
        }
    }
}
